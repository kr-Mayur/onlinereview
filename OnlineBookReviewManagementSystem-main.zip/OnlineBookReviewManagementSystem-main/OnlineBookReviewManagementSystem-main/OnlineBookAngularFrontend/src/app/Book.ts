export class Book
{
	id: number;
    author: string;
    name: string;
    price: number;
    category: string;
}